### 1.1.3
- Correct error with failsafe not engaging

### 1.1.2
- Remove acetone pressure display

### 1.1.1
- Show acetone pressure on-screen

### 1.1.0
- Switch from flow sensor to pressure transducer on acetone line

### 1.0.2
- Adjust the time window for catalyst backflow, changing the millis window from 30,000-350,000 to 250,000-350,000.
- Add the "badOne" system to backflow


### 1.0.1
- Add time cooldown time of 1 second to activate bypass mode.


### 1.0.0
- Initial version